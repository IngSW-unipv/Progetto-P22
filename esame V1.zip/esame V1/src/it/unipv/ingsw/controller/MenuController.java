package src.it.unipv.ingsw.controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import src.it.unipv.ingsw.view.AppView;
import src.it.unipv.ingsw.view.MenuView;

public class MenuController implements ActionListener{
	
	private static MenuView m;
	private static AppView a;
	
	public  MenuController(MenuView m) {
		super();
		this.m=m;
	}
	
	public  MenuController(AppView a) {
		super();
		this.a=a;
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		System.out.println(e.getActionCommand());
		try {
			if (e.getSource().equals("AppView.cercaRistoranti")) {
				System.out.println("true_MenuController ");

			} 
			
			m.setVisible(true);
			a.setVisible(false);
		} catch (NullPointerException n) {
			System.err.println("ERRORE: evento nullo");
		}
	}
}
