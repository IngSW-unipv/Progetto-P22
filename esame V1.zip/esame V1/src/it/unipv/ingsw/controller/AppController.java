package src.it.unipv.ingsw.controller;

public class AppController {
//	qua bisogna mettere il metodo per la posizione e per aprire il menu dei ristoranti
}
