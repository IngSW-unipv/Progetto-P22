package src.it.unipv.ingsw.controller;

import src.it.unipv.ingsw.database.ClienteDAO;
import src.it.unipv.ingsw.database.DBConnectionSingleton;
import src.it.unipv.ingsw.model.Cliente;
import src.it.unipv.ingsw.model.Utente;
import src.it.unipv.ingsw.view.AccessoView;
import src.it.unipv.ingsw.view.RegistrazioneView;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;

public class UtenteController implements ActionListener {
    private Utente model;
    
    private static AccessoView accessoView;
    private static RegistrazioneView registrazioneView;

    public UtenteController(AccessoView a) {
    	super();
    	UtenteController.accessoView = a;
    }
    
    public UtenteController(RegistrazioneView r) {
    	super();
    	UtenteController.registrazioneView = r;
    }
    
    public void setModel(Utente model) {
        this.model = model;
    }

    private void registra() {
        try {
            String nome = registrazioneView.getNome();
            String cognome = registrazioneView.getCognome();
            String email = registrazioneView.getEmail();
            String password = registrazioneView.getPassword();

            // Creare un nuovo cliente
            Cliente nuovoCliente = new Cliente(nome, cognome, email, password);

            // Inserire il cliente nel database
            Connection conn = DBConnectionSingleton.getInstance().getConnection();
            ClienteDAO clienteDAO = new ClienteDAO(conn);
            boolean success = clienteDAO.insertCliente(nuovoCliente);

            if (success) {
                System.out.println("Registrazione completata con successo");
                showAppView();
            } else {
                System.err.println("Errore durante la registrazione");
            }

        } catch (Exception e) {
            e.printStackTrace();
            System.err.println("Errore durante la registrazione");
        }
    }
	@Override
	public void actionPerformed(ActionEvent e) {
//		comado per test
//			System.out.println(e.getActionCommand());
		try {
			if (e.getActionCommand().equals("AccessoView.accedi")) {
				accedi();
			} 
			else if (e.getActionCommand().equals("RegistrazioneView.registrati")) {
				registra();
			} else
				System.out.println("ERRORE: valore pulsante non valido");
		} catch (NullPointerException n) {
			System.err.println("ERRORE: evento nullo");
		}
	}
	
	private void accedi() {
//	qua serve un operazione che permetta di controllare se l'utente esiste e do accedere
		showAppView();
	}
	
	
	private void showAppView() {
//	questa serve per mostrare l'app vera e propria
	}
}
