package src.it.unipv.ingsw.database;

public abstract class SchemaDB {
	
	protected final static String SCHEMA = "splash_db";
}
